clear all
clc
tic
rr=600;%�������룬���ͨѶ����
Rmax=100;%��Ư����
R=600;%�ִؾ���
C=[400 1000 635 612 456 1036 121 1051 785 784 415 719 236 1320 124 1400 1000 1470 154 1500;
    400 842 974 145 982 454 698 64 454 256 624 351 1014 789 564 1210 1210 360 1190 1500;
    130 200 180 195 150 177 90 106 220 230 146 270 311 321 300 110 240 140 190 200];
%5O=[1500,1500,200];%%Ŀ��ڵ�
%S=[400,400,130]; %&��Ϣ����Դ
%C=[1000 842 200;635 974 180;612 145 195;456 982 150;1036 454 177;121 698 90;1051 64 106;785 454 220;784 256 230;
   % 415 624 146;719 351 270;236 1014 311;1320 789 321;124 564 300;1400 1210 110;1000 1210 240;1470 360 140;154 1190 190];%�������˻�����
[V,Acci,Vcci,Fai]=S6V(C);
C=V;
Copy=C;
D=G6D(C);
Dcopy=D;
Nc=1;
r=0;
NC_max=20;
Final=cell(1,20);
Loss=[];
Point=[];
Path=5;%��ϢԴ�ڵ�
Linkmax=15;
%Dlong=[19,7,11,4,8,16,14,17,20];%%%��5�Žڵ�Ϊ�����ͨѶ��·
Dlong=[19 7 11 4 8 6 14 17 20];%%%��1�Žڵ�Ϊ�����ͨѶ��·
while Nc<=NC_max
n=size(C,2);
node=cell(1,n);
D_1=[];
D1ne=[];
Ne=[];    
Number=[];
for i=1:n
    N=0;
    Ne=[];
    for j=1:n
        a=D(i,j);
        if a<=R
            N=N+1;
            Ne=[Ne j];
        end
    end
    Number=[Number N];
    node{1,i}=Ne;
end
%%%%%%%%%%%%%�Ƚϴ�С%%%%%%%%%%%%%
min=0;
for i=1:n
    max=Number(i);
    if max>min
        min=max;
        D1=i;
    end
end
D_1=[D_1 C(:,D1)];
Ne_D=node{1,D1};
e=length(Ne_D);
if e~=0
for k=1:e
    a=Ne_D(k);
    c1=C(:,a);
D1ne=[D1ne c1];
end
end
final=[D_1 D1ne];
Final{Nc}=final;
Nc=Nc+1;
D(D1,:)=inf;
D(:,D1)=inf;
if e~=0
for k=1:e
    a=Ne_D(k);
    D(:,a)=inf;
    D(a,:)=inf;
end
end
r=0;
for i=1:20
    for j=1:20
        c2=D(i,j);
        if c2<R
            r=r+1;
        end
    end
end
if  r==0
    Nc=21;
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����Ϊ�ִع���%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Com=[];
for i=1:n %%%%%%%��t���� ����δ���ӵĵ�ʱ  ��Ϊ2
A=Final{1,i}; 
c=length(A);
if c~=0
    Com=[Com A(2,:)];
end
end
[p1,p2]=ismember(C(2,:),Com);
for i=1:n
    if p1(1,i)==0
        Loss=[Loss C(:,i)];
        Point=[Point i];
    end
end
%disp(Point)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%�ҳ������ȴ��ڵ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
e=size(Point,2);
Final2=cell(1,e);
for i=1:e
    final2=[];
    for j=1:n
        if Dcopy(Point(i),j)<R
        final2=[final2 C(:,j)];
        end
    end
    Final2{1,i}=[Loss(:,i) final2];
end
%disp(Final2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�ȴ��ڵ����·�%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ind=~cellfun(@isempty,Final);
[line,list]=find(ind==1);
l=size(line,2);
A1=Final{1,1};
A2=Final{1,2};
disp(A1)
disp(A2)
I=size(A1,2);
I2=size(A2,2);
for i=1:I
    for j=1:I2
        Dclu(i,j)=((A1(1,i)-A2(1,j))^2+(A1(2,i)-A2(2,j))^2)^0.5;
    end
end
minall=inf;
for i=1:I
    for j=1:I2
       if Dclu(i,j)<minall
        minall=Dclu(i,j);
        minline=i;
        minlist=j;
       end
    end
end
%disp(minline) ��ʾ��
%disp(minlist) ��ʾ��
Final3=[A1(:,minline) A2(:,minlist)];
disp(Final3)
%disp(D_1)
%disp(Com)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�������%%%%%%%%%%%%%%%%%%%%%%
La1=0;
io=length(A1);
for i=2:io
    D=((A1(1,1)-A1(1,io))^2+(A1(2,1)-A1(2,io))^2)^0.5;
    La1=La1+D;
end
La2=0;
io=length(A2);
for i=2:io
    D=((A2(1,1)-A2(1,io))^2+(A2(2,1)-A2(2,io))^2)^0.5;
    La2=La2+D;
end
La3=0;
ee=length(Final2);
for i=1:ee
    A3=Final2{1,i};
    d=size(A3,2);
    for j=2:d
        D=((A3(1,1)-A3(1,j))^2+(A3(2,1)-A3(2,j))^2)^0.5;
        La3=La3+D;
    end   
end
La4=((Final3(1,1)-Final3(1,2))^2+((Final3(2,1)-Final3(2,2))^2))^0.5;
D_all=La1+La2+La3+La4;
disp(D_all)
disp(Dcopy)

%% ��������%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  A11=[11,1,3,4,5,7,9,10,12,13,15];
%  A12=[14,2,6,16,17,18];
%  A13=[20,16,17];
%  A14{1,1}=[8,4,6,9,10,12,18];
%  A14{1,2}=[19,3,5,7,13];
%  A14{1,3}=[20,16,17];%1-5��

% A11=[11,1,2,3,5,6,7,9,10,12,13,15,19];
% A12=[14,16,17,18];
% A13=[20,16,17];
% A14{1,1}=[4,1,6,8,9,10,12];
% A14{1,2}=[8,4,6,9,10,12,18];
% A14{1,3}=[20,16,17];%6-10��

% A11=[11,1,3,5,6,7,2,9,10,12,13,15,19];
% A12=[8,4,14,18];
% A13=[20,16,17]; 
% A14{1,1}=[16,2,9,14,17,20];
% A14{1,2}=[17,2,9,16,20];
% A14{1,3}=[20,16,17];%11-16��

A11=[11,1,2,3,5,6,7,9,10,12,13,19];
A12=[8,4,14,18];
A13=[20,16,17]; 
A14{1,1}=[13,3,5,19];
A14{1,2}=[15,7];
A14{1,3}=[20,16,17];
A14{1,4}=[17,2,16,20];%11-16��

A1=[];
A2=[];
A3=[];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����A14ʱ��Ҫ�ⲿ�ּ���
koj=length(A14);
 Final2=cell(1,koj);
 for i=1:koj
     koi=size(A14{1,i},2);
     for j=1:koi
       Final2{1,i}=[Final2{1,i} C(:,A14{1,i}(1,j))];  
     end
 end   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
kol=length(A11);
for i=1:kol
    A1=[A1 C(:,A11(1,i))];
end
kol=length(A12);
for i=1:kol
    A2=[A2 C(:,A12(1,i))];
end
kol=length(A13);
for i=1:kol
    A3=[A3 C(:,A13(1,i))];
end
%%%%%�ڵ㸺��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%�ڵ㸺��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
o=length(A1);%%����ؽڵ���غ�ֵ��������غ�Ϊ5��
Jlod=atan(1-o/Linkmax);

%%%%%%%%ͨ��Ч��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 o=length(Final2);
 DdistanceT=[];
 for i=1:o
     AA=Final2{1,i};
     distanceT=0;
     oo=size(AA,2);  
     for j=1:oo-1
        distanceT=distanceT+((AA(1,j+1)-AA(1,j))^2+...
            (AA(2,j+1)-AA(2,j))^2+(AA(3,j+1)-AA(3,j))^2)^0.5;
        distanceT=R/(distanceT*oo);
     end
     DdistanceT=[DdistanceT distanceT];
 end
 jj=length(DdistanceT);
 jrel=inf;
 for i=1:jj
     if jrel>DdistanceT(1,jj)
         jrel=DdistanceT(1,jj);
     end
 end
%  Dlong=[19,7,11,4,8,16,14,17,20];%%%�ͨѶ��·
 dlong=length(Dlong);
 jreal=0;
 for i=1:dlong-1
     jreal=jreal+Dcopy(i+1,i);
 end
 jreal=rr/(jreal*(dlong-1));
 %jrel=min(DdistanceT);
 Jrel=atan(jreal);

 %%%%�����ع�����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Bw=500;%�ŵ�����
wik=15;%�źŷ��书��
epsilon=1;%˥��ϵ��
z0=-174;%��λ��������������
DW=180;%��λ����ֵ���������ܶ�-174dbm/Hz,����1MHz,��������=-174dbm*180khz
o=length(A1);
Jzong=0;
for j=1:o-1
   
    distanceT=((A1(1,j+1)-A1(1,j))^2+...
            (A1(2,j+1)-A1(2,j))^2+(A1(3,j+1)-A1(3,j))^2)^0.5;
        
        Jijrou=real(Bw*log2(1+(wik*distanceT^2)/(z0*Bw*DW)));
  
    Jzong=Jzong+Jijrou;
end
o=length(A2);
for j=1:o-1
    distanceT=((A2(1,j+1)-A2(1,j))^2+...
            (A2(2,j+1)-A2(2,j))^2+(A2(3,j+1)-A2(3,j))^2)^0.5;     
        Jijrou=real(Bw*log2(1+(wik*distanceT^2)/(z0*Bw*DW)));
    Jzong=Jzong+Jijrou;
end
o=length(Final2);
DdistanceT=[];
for i=1:o
    AA=Final2{1,i};
    oo=size(AA,2);  
    for j=1:oo-1
        distanceT=((AA(1,j+1)-AA(1,j))^2+...
            (AA(2,j+1)-AA(2,j))^2+(AA(3,j+1)-AA(3,j))^2)^0.5;
        Jijrou=Bw*log2(1+(wik*distanceT^2)/(z0*Bw*DW));
        %CCC=1+(wik*distanceT^2)/(z0*Bw*DW)
        Jzong=Jzong+Jijrou;
    end  
end
Jzong=Jzong/10000;
Jrest=atan(Jzong);
%Jrest=Jzong;

%%%%��������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
AA5=[];
Timezong=[];
%AA4=[A1(:,2:end) A2(:,2:end)];%%%%��ȥ��ͷ�󣬴�Ⱥ�ڳ��ֹ��ĵ㡣
o=length(Final2);
for i=1:o
    AA5=[AA5 Final2{1,i}(:,2:end)]; %#ok<AGROW> Wp��Զ�����·ѡ��
end
Calone=[];
Calone2=[];
Cal=setdiff(A1(1,2:end),AA5); %%%%��Ⱥһ�еĶ����ڵ�
oo=size(Cal,1);
for i=1:oo
    [row,col]=find(Cal(i,1)==C);
    Calone=[Calone C(:,col)];
end
Cal2=setdiff(A2(1,2:end),AA5); %%%%��Ⱥ2�еĶ����ڵ�
ooo=size(Cal2,1);
if (ooo-1)>0
for i=1:ooo
    [row,col]=find(Cal2(i,1)==C);
    Calone2=[Calone2 C(:,col)];
end
end
% Model=size(Calone,1)/3;
% Model2=size(Calone2,1)/3;
% Calone=reshape(Calone,[3,Model]);
% Calone2=reshape(Calone2,[3,Model2]);
o=size(Calone,2);
for i=1:o
    AA=A1(:,1);
    AAcopy=AA;
    [row,col]=find(AA(1,1)==C);
    [row2,col2]=find(Calone(1,i)==C);
    for j=1:20
        %%%%������·�����˶ϵ�1
        X1=AAcopy(1,1);
         Y1=AAcopy(2,1);
         X2=Calone(1,i);
         Y2=Calone(2,i);
        ai=Acci(1,col);
        vi=Vcci(1,col);
        faii=Fai(1,col);
        aix=ai*cos(faii);
        aiy=ai*sin(faii);
        vix=vi*cos(faii);
        viy=vi*sin(faii);
        xi=ceil(X1+(vix)*j+1/2*aix*j^2);
        yi=ceil(Y1+(viy)*j+1/2*aiy*j^2);  %λ��Ԥ��+aix*j  +aiy*j
        AA(1,1)=xi; 
        AA(2,1)=yi;
        %%%%������·�����˶ϵ�2
        ai=Acci(1,col2);
        vi=Vcci(1,col2);
        faii=Fai(1,col2);
        aix=ai*cos(faii);
        aiy=ai*sin(faii);
        vix=vi*cos(faii);
        viy=vi*sin(faii);
        xi=ceil(X2+(vix)*j+1/2*aix*j^2);
        yi=ceil(Y2+(viy)*j+1/2*aiy*j^2);  %λ��Ԥ��+aix*j  +aiy*j
        Calone(1,i)=xi; 
        Calone(2,i)=yi;
        %%%%%%%%%%�����ж�
        Dcui=((AA(1,1)-Calone(1,i))^2+...
            (AA(2,1)-Calone(2,i))^2+(AA(3,1)-Calone(3,i))^2)^0.5+Rmax;
        if Dcui>rr
            Timezong=[Timezong j];
            break
        end
    end
end
o=size(Calone2,2);
for i=1:o
    AA=A2(:,1);
    AAcopy=AA;
    [row,col]=find(AA(1,1)==C);
    [row2,col2]=find(Calone2(1,i)==C);
    ooo=length(col2);
    if ooo>1
        [row2,col2]=find(Calone2(2,i)==C);
    end
    for j=1:20
        X1=AAcopy(1,1);
         Y1=AAcopy(2,1);
         X2=Calone2(1,i);
         Y2=Calone2(2,i);
        %%%%������·�����˶ϵ�1
        ai=Acci(1,col);
        vi=Vcci(1,col);
        faii=Fai(1,col);
        aix=ai*cos(faii);
        aiy=ai*sin(faii);
        vix=vi*cos(faii);
        viy=vi*sin(faii);
        xi=ceil(X1+(vix)*j+1/2*aix*j^2);
        yi=ceil(Y1+(viy)*j+1/2*aiy*j^2);  %λ��Ԥ��+aix*j   +aiy*j
        AA(1,1)=xi;
        AA(2,1)=yi;
        %%%%������·�����˶ϵ�2
        ai=Acci(1,col2);
        vi=Vcci(1,col2);
        faii=Fai(1,col2);
        aix=ai*cos(faii);
        aiy=ai*sin(faii);
        vix=vi*cos(faii);
        viy=vi*sin(faii);
        xi=ceil(X2+(vix)*j+1/2*aix*j^2);
        yi=ceil(Y2+(viy)*j+1/2*aiy*j^2);  %λ��Ԥ��+aix*j +aiy*j
        Calone2(1,i)=xi; 
        Calone2(2,i)=yi;
        %%%%%%%%%%�����ж�
        Dcui=((AA(1,1)-Calone2(1,i))^2+...
            (AA(2,1)-Calone2(2,i))^2+(AA(3,1)-Calone2(3,i))^2)^0.5+Rmax;
        if Dcui>rr
            Timezong=[Timezong j];
            break
        end
    end
end
oo=length(Timezong);
jcc=inf;
for i=oo
    if jcc>Timezong(1,i)
        jcc=Timezong(1,i);
    end
end
jcdes1=jcc;
jcc2=inf;
for i=1:20
    for j=1:20
        if jcc2>Dcopy(i,j);
            jcc2=Dcopy(i,j);
        end
    end
end
%jcc2=min(min(Dcopy));
jcdes2=ceil(jcc2/50);
Jcdes=0.8*jcdes1+0.2*jcdes2;
Jij=0.1*Jrel+0.3*Jrest+Jlod*0.3+0.3*Jcdes;
