clear all
clc
tic
rr=600;%�������룬���ͨѶ����
Rmax=100;%��Ư����
R=600;%����ִؾ���,�����ڽڵ㲻�ڴ�Ⱥ��ʱ�䣬����Ϊ900
C=[400 1000 635 612 456 1036 121 1051 785 784 415 719 236 1320 124 1400 1000 1470 154 1500;
    400 842 974 145 982 454 698 64 454 256 624 351 1014 789 564 1210 1210 360 1190 1500;
    130 200 180 195 150 177 90 106 220 230 146 270 311 321 300 110 240 140 190 200];
%5O=[1500,1500,200];%%Ŀ��ڵ�
%S=[400,400,130]; %&��Ϣ����Դ
%C=[1000 842 200;635 974 180;612 145 195;456 982 150;1036 454 177;121 698 90;1051 64 106;785 454 220;784 256 230;
   % 415 624 146;719 351 270;236 1014 311;1320 789 321;124 564 300;1400 1210 110;1000 1210 240;1470 360 140;154 1190 190];%�������˻�����
[V,Acci,Vcci,Fai]=S6V(C);
C=V;
D=G6D(C);
Dcopy=D;
Nc=1;
r=0;
NC_max=20;
Final=cell(1,20);
Loss=[];
Point=[];
Path=5;%��ϢԴ�ڵ�
Linkmax=15;
%Dlong=[19,7,11,4,8,16,14,17,20];%%%��5�Žڵ�Ϊ�����ͨѶ��·
Dlong=[19 7 11 4 8 6 14 17 20];%%%��1�Žڵ�Ϊ�����ͨѶ��·
A3=[];
while Nc<=NC_max
n=size(C,2);
node=cell(1,n);
D_1=[];
D1ne=[];
Ne=[];    
Number=[];
for i=1:n
    N=0;
    Ne=[];
    for j=1:n
        a=D(i,j);
        if a<=R
            N=N+1;
            Ne=[Ne j];
        end
    end
    Number=[Number N];
    node{1,i}=Ne;
end
%%%%%%%%%%%%%�Ƚϴ�С%%%%%%%%%%%%%
min=0;
for i=1:n
    max=Number(i);
    if max>min
        min=max;
        D1=i;
    end
end
D_1=[D_1 C(:,D1)];
Ne_D=node{1,D1};
e=length(Ne_D);
if e~=0
for k=1:e
    a=Ne_D(k);
    c1=C(:,a);
D1ne=[D1ne c1];
end
end
final=[D_1 D1ne];
Final{Nc}=final;
Nc=Nc+1;
D(D1,:)=inf;
D(:,D1)=inf;
if e~=0
for k=1:e
    a=Ne_D(k);
    D(:,a)=inf;
    D(a,:)=inf;
end
end
r=0;
for i=1:20
    for j=1:20
        c2=D(i,j);
        if c2<R
            r=r+1;
        end
    end
end
if  r==0
    Nc=21;
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����Ϊ�ִع���%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Com=[];
for i=1:2  %%%%%%%��t���� ����δ���ӵĵ�ʱ  ��Ϊ2
A=Final{1,i};
c=length(A);
if c~=0
    Com=[Com A(2,:)];
end
end
[p1,p2]=ismember(C(2,:),Com);
for i=1:n
    if p1(1,i)==0
        Loss=[Loss C(:,i)];
        Point=[Point i];
    end
end

% ooo=length(Point);
% if ooo==0
%     o=length(Final{1,3});
%     for i=1:o
%         [ro,co]=find(Final{1,3}(1,i)==C);
%     Point=[Point co];
%     end
% end
% disp(Point)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%�ҳ������ȴ��ڵ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
e=size(Point,2);
Final2=cell(1,e);
for i=1:e
    final2=[];
    for j=1:n
        if Dcopy(Point(i),j)<R
        final2=[final2 C(:,j)];
        end
    end
    Final2{1,i}=[Loss(:,i) final2];
end
%disp(Final2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�ȴ��ڵ����·�%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ind=~cellfun(@isempty,Final);
[line,list]=find(ind==1);
l=size(line,2);
A1=Final{1,1}; %%%��ŵ��Ǵ�ͷ1
A2=Final{1,2}; %%%����Ǵ�ͷ2 
disp(A1)
disp(A2)
I=size(A1,2);
I2=size(A2,2);
for i=1:I
    for j=1:I2
        Dclu(i,j)=((A1(1,i)-A2(1,j))^2+(A1(2,i)-A2(2,j))^2)^0.5;
    end
end
minall=inf;
for i=1:I
    for j=1:I2
       if Dclu(i,j)<minall
        minall=Dclu(i,j);
        minline=i;
        minlist=j;
       end
    end
end
%disp(minline) ��ʾ��
%disp(minlist) ��ʾ��
Final3=[A1(:,minline) A2(:,minlist)];
disp(Final3)
%disp(D_1)
%disp(Com)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�������%%%%%%%%%%%%%%%%%%%%%%
La1=0;
io=length(A1);
for i=2:io
    D=((A1(1,1)-A1(1,io))^2+(A1(2,1)-A1(2,io))^2)^0.5;
    La1=La1+D;
end
La2=0;
io=length(A2);
for i=2:io
    D=((A2(1,1)-A2(1,io))^2+(A2(2,1)-A2(2,io))^2)^0.5;
    La2=La2+D;
end
La3=0;
ee=length(Final2);
for i=1:ee
    A3=Final2{1,i};
    d=size(A3,2);
    for j=2:d
        D=((A3(1,1)-A3(1,j))^2+(A3(2,1)-A3(2,j))^2)^0.5;
        La3=La3+D;
    end   
end
La4=((Final3(1,1)-Final3(1,2))^2+((Final3(2,1)-Final3(2,2))^2))^0.5;
D_all=La1+La2+La3+La4;
disp(D_all)
disp(Dcopy)



%% ��Final2�������򣬴����ڵ�����Ϊ�ؽڵ�
oo=length(Final2);
Final2fu=Final2;
Arow=[];
for ii=1:oo
    [aa1,bb1]=size(Final2{1,ii});
    Arow=[Arow bb1];
end
[XX,YY]=sort(Arow);
XXz=fliplr(XX);
YYz=fliplr(YY);
oo=length(YYz);
for i=1:oo
    Final2{1,i}=Final2fu{1,YYz(1,i)};
end

%% �Ժ�����չ�����е���·�����޸�%%
%%%%%Final2�Ѿ�������ɣ���һ��������Ϊ��ͷ���󣬺����Ϊwh����Ҫ��չ��
oo=length(Final2);
MMax=inf;
MMax2=inf;
Dis2=[];
if oo~=0
for ii=2:oo
    if ii==2
    Ay=Final2{1,ii};
    ooo=size(Ay,2);
    for kk=2:ooo
        Dis2(1,kk-1)=(Ay(1,kk)-Ay(1,1))^2+(Ay(2,kk)-Ay(2,1))^2+(Ay(3,kk)-Ay(3,1))^2;
    end
    for kk1=1:ooo-1
        if Dis2(1,kk1)<MMax
            MMax=Dis2(1,kk1);
            K1=kk1+1;
        end
    end
    Final2{1,ii}=[Final2{1,ii}(:,1) Final2{1,ii}(:,K1)];
    end
    
    
    if ii==oo
    Ay1=Final2{1,ii};
    ooo=size(Ay1,2);
    for kkk=2:ooo
        Dis3(1,kkk-1)=(Ay1(1,kkk)-Ay1(1,1))^2+(Ay1(2,kkk)-Ay1(2,1))^2+(Ay1(3,kkk)-Ay1(3,1))^2;
    end
    for kkk1=1:ooo-1
        if Dis3(1,kkk1)<MMax2
            MMax2=Dis2(1,kkk1);
            Kk1=kkk1+1;
        end
    end
    Final2{1,ii}=[Final2{1,ii}(:,1) Final2{1,ii}(:,Kk1)];
    end
    
end
end


%% �ִع���%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%���ǵ�ͨ��Ч���еı���֮�;����йأ��������ͨ���ȽϾ�����ȷ����Ⱥ��ϵ
%%% A1��ʾ��Ⱥ1��A2��ʾ��Ⱥ2��Final2{1,1}��ʾ��Ⱥ����


%%%��һ����ȷ�������е���ͬԪ�� A1 �� A2;
AA1=A1;
AA2=A2;
Lsame=ismember(AA1(1,:),AA2(1,:));%%��Ⱥ1�ʹ�Ⱥ2֮����ͬԪ�صĸ�ʽ��
count=sum(sum(Lsame~=0));%%�����1�ʹ�2ͬʱ�����Ľڵ�����
oo=length(Lsame);
Distance12=[];
Distance3=[];
Nodecun=[];
MAx=inf;
for ii=1:oo
    if Lsame(1,ii)~=0
        distance1=(AA1(1,1)-AA1(1,ii))^2+(AA1(2,1)-AA1(2,ii))^2+(AA1(3,1)-AA1(3,ii))^2;
        [aa,bb]=find(AA1(1,ii)==AA2(1,:));
        distance2=(AA2(1,1)-AA2(1,bb))^2+(AA2(2,1)-AA2(2,bb))^2+(AA2(3,1)-AA2(3,bb))^2;
        distance3=distance1+distance2;
        Distance12=[Distance12 [distance1;distance2]];
        Distance3=[Distance3 distance3];
        Nodecun=[Nodecun ii];
    end
end
%%%�ڶ�����ɾ����·��Ϣ
Aempty=isempty(Distance12);
if Aempty==0
     KK=length(Distance3);
    for kk=1:KK
        if Distance3(1,kk)<MAx
            MAx=Distance3(1,kk);
            Dismin=Distance3(1,kk);
        end
    end
    [aa,bb]=find(Dismin==Distance3);
    Distance12(:,[bb])=[];%%%����ͬԪ�ؾ�����ɾ���Žӽڵ�
    dd=size(Distance12,2);
    for jj=1:dd %%%%�ִ�
        if Distance12(1,jj)>Distance12(2,jj)
            AA1(:,[Nodecun(1,jj)])=[];
        end
        if Distance12(1,jj)<Distance12(2,jj)
            [~,bb]=find(AA1(1,Nodecun(1,jj))==AA2(1,:));%%~��ʾδʹ������
            AA2(:,[bb])=[];
        end
    end   
end
A1=AA1;
A2=AA2;

%%%��һ����ȷ�������е���ͬԪ�� A1 �� Final2{1,1};
AA1=A1;
AA2=Final2{1,1};
Lsame=ismember(AA1(1,:),AA2(1,:));%%��Ⱥ1�ʹ�Ⱥ2֮����ͬԪ�صĸ�ʽ��
count=sum(sum(Lsame~=0));%%�����1�ʹ�2ͬʱ�����Ľڵ�����
oo=length(Lsame);
Distance12=[];
Distance3=[];
Nodecun=[];
MAx=inf;
for ii=1:oo
    if Lsame(1,ii)~=0
        distance1=(AA1(1,1)-AA1(1,ii))^2+(AA1(2,1)-AA1(2,ii))^2+(AA1(3,1)-AA1(3,ii))^2;
        [aa,bb]=find(AA1(1,ii)==AA2(1,:));
        distance2=(AA2(1,1)-AA2(1,bb))^2+(AA2(2,1)-AA2(2,bb))^2+(AA2(3,1)-AA2(3,bb))^2;
        distance3=distance1+distance2;
        Distance12=[Distance12 [distance1;distance2]];
        Distance3=[Distance3 distance3];
        Nodecun=[Nodecun ii];
    end
end

%%%�ڶ�����ɾ����·��Ϣ
Aempty=isempty(Distance12);
if Aempty==0
    KK=length(Distance3);
    for kk=1:KK
        if Distance3(1,kk)<MAx
            MAx=Distance3(1,kk);
            Dismin=Distance3(1,kk);
        end
    end
    [aa,bb]=find(Dismin==Distance3);
    Distance12(:,[bb])=[];%%%����ͬԪ�ؾ�����ɾ���Žӽڵ�
    dd=size(Distance12,2);
    for jj=1:dd %%%%�ִ�
        if Distance12(1,jj)>Distance12(2,jj)
            AA1(:,[Nodecun(1,jj)])=[];
        end
        if Distance12(1,jj)<Distance12(2,jj)
            [~,bb]=find(AA1(1,Nodecun(1,jj))==AA2(1,:));%%~��ʾδʹ������
           AA2(:,[bb])=[];
        end
    end   
end
Final2{1,1}=AA2;
A1=AA1;


%%%��һ����ȷ�������е���ͬԪ�� A2 �� Final2{1,1};
AA1=A2;
AA2=Final2{1,1};
Lsame=ismember(AA1(1,:),AA2(1,:));%%��Ⱥ1�ʹ�Ⱥ2֮����ͬԪ�صĸ�ʽ��
count=sum(sum(Lsame~=0));%%�����1�ʹ�2ͬʱ�����Ľڵ�����
oo=length(Lsame);
Distance12=[];
Distance3=[];
Nodecun=[];
MAx=inf;
for ii=1:oo
    if Lsame(1,ii)~=0
        distance1=(AA1(1,1)-AA1(1,ii))^2+(AA1(2,1)-AA1(2,ii))^2+(AA1(3,1)-AA1(3,ii))^2;
        [aa,bb]=find(AA1(1,ii)==AA2(1,:));
        distance2=(AA2(1,1)-AA2(1,bb))^2+(AA2(2,1)-AA2(2,bb))^2+(AA2(3,1)-AA2(3,bb))^2;
        distance3=distance1+distance2;
        Distance12=[Distance12 [distance1;distance2]];
        Distance3=[Distance3 distance3];
        Nodecun=[Nodecun ii];
    end
end
%%%�ڶ�����ɾ����·��Ϣ
Aempty=isempty(Distance12);
if Aempty==0
    KK=length(Distance3);
    for kk=1:KK
        if Distance3(1,kk)<MAx
            MAx=Distance3(1,kk);
            Dismin=Distance3(1,kk);
        end
    end
    [aa,bb]=find(Dismin==Distance3);
    Distance12(:,[bb])=[];%%%����ͬԪ�ؾ�����ɾ���Žӽڵ�
    dd=size(Distance12,2);
    for jj=1:dd %%%%�ִ�
        if Distance12(1,jj)>Distance12(2,jj)
            AA1(:,[Nodecun(1,jj)])=[];
        end
        if Distance12(1,jj)<Distance12(2,jj)
            [~,bb]=find(AA1(1,Nodecun(1,jj))==AA2(1,:));%%~��ʾδʹ������
            AA2(:,[bb])=[];
        end
    end   
end
Final2{1,1}=AA2;
A2=AA1;

%% �������ͨ������%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% �����ع����� 
Bw=500;%�ŵ�����
wik=15;%�źŷ��书��
epsilon=1;%˥��ϵ��
z0=-174;%��λ��������������
DW=180;%��λ����ֵ���������ܶ�-174dbm/Hz,����1MHz,��������=-174dbm*180khz
o=length(A1);
Jzong=0;
for j=1:o-1
   
    distanceT=((A1(1,j+1)-A1(1,j))^2+...
            (A1(2,j+1)-A1(2,j))^2+(A1(3,j+1)-A1(3,j))^2)^0.5;
        
        Jijrou=real(Bw*log2(1+(wik*distanceT^2)/(z0*Bw*DW)));
  
    Jzong=Jzong+Jijrou;
end
o=length(A2);
for j=1:o-1
    distanceT=((A2(1,j+1)-A2(1,j))^2+...
            (A2(2,j+1)-A2(2,j))^2+(A2(3,j+1)-A2(3,j))^2)^0.5;     
        Jijrou=real(Bw*log2(1+(wik*distanceT^2)/(z0*Bw*DW)));
    Jzong=Jzong+Jijrou;
end
o=length(Final2);
DdistanceT=[];
for i=1:o
    AA=Final2{1,i};
    oo=size(AA,2);  
    for j=1:oo-1
        distanceT=((AA(1,j+1)-AA(1,j))^2+...
            (AA(2,j+1)-AA(2,j))^2+(AA(3,j+1)-AA(3,j))^2)^0.5;
        Jijrou=Bw*log2(1+(wik*distanceT^2)/(z0*Bw*DW));
        %CCC=1+(wik*distanceT^2)/(z0*Bw*DW)
        Jzong=Jzong+Jijrou;
    end  
end
Jzong=Jzong/10000;
Jrest=atan(Jzong);
%Jrest=Jzong;


%% ��Բ�����ִַؿռ�
% figure (2)
% [x,y,z2]=sphere(20);
% %z2(z2<0)=nan;
% %x(x<0)=nan;
% %y(y>0)=nan;
% mesh(600*x+A1(1,1),600*y+A1(2,1),600*z2+A1(3,1));
% camlight;lighting gouraud;
% alpha(0.1)
% hold on
% 
% [x,y,z2]=sphere(20);
% %z2(z2<0)=nan;
% %x(x<0)=nan;
% %y(y>0)=nan;
% mesh(600*x+A2(1,1),600*y+A2(2,1),600*z2+A2(3,1));
% camlight;lighting gouraud;
% alpha(0.1)
% hold on
% 
% [x,y,z2]=sphere(20);
% %z2(z2<0)=nan;
% %x(x<0)=nan;
% %y(y>0)=nan;
% mesh(600*x+Final2{1,1}(1,1),600*y+Final2{1,1}(2,1),600*z2+Final2{1,1}(3,1));
% camlight;lighting gouraud;
% alpha(0.1)
% hold on

%% ��ͼ�����������ص㣬�����ŵ�4���ȴ��㡣�ص�ΪFinal�������ÿ��������Ŀ�ͷ��һ��%%
%%%%%%%%%%%%%%%%�ŵ�����Final3,4���ȴ������Point�С�%%%%%%%%%%%%%
figure (1)
% CC=C;
% [~,bb]=find(A1(1,1)==CC);
% CC(:,[bb])=[];
% [~,bb]=find(A2(1,1)==CC);
% CC(:,[bb])=[];
% oo=length(Final2)
% [~,bb]=find(Final2{1,1}(1,1)==CC);
% CC(:,[bb])=[];
% [~,bb]=find(Final2{1,2}(1,1)==CC);
% CC(:,[bb])=[];
% [~,bb]=find(Final2{1,3}(1,1)==CC);
% CC(:,[bb])=[]; %%��ͼʱ�õ�
% scatter3(CC(1,:),CC(2,:),CC(3,:),80,'filled','LineWidth',1.5);
% hold on
scatter3(C(1,:),C(2,:),C(3,:),80,'filled','LineWidth',1.5);
hold on
% scatter3(A1(1,1),A1(2,1),A1(3,1),80,'r','filled','LineWidth',1.5);
% hold on
% scatter3(A2(1,1),A2(2,1),A2(3,1),80,'r','filled','LineWidth',1.5);
% hold on
% scatter3(Final2{1,1}(1,1),Final2{1,1}(2,1),Final2{1,1}(3,1),80,'r','filled','LineWidth',1.5);
% hold on
% scatter3(Final2{1,2}(1,1),Final2{1,2}(2,1),Final2{1,2}(3,1),80,'k','filled','LineWidth',1.5);
% hold on
% scatter3(Final2{1,3}(1,1),Final2{1,3}(2,1),Final2{1,3}(3,1),80,'k','filled','LineWidth',1.5);
% hold on ��ͼʱ�õ�
%text(C(1,Path(1,1)),C(2,Path(1,1)),'Ns','VerticalAlignment','bottom');
%text(A1(1,1),A1(2,1),'Ch','VerticalAlignment','bottom');
%text(A2(1,1),A2(2,1),'Ch','VerticalAlignment','bottom');%%��ͷ
e=length(Point);
 for i=1:e
 text(C(1,Point(1,i)),C(2,Point(1,i)),C(3,Point(1,i)),'Wp','VerticalAlignment','bottom');
 end  %%%%%�ȴ��ڵ�
  hold on
  
   text(A1(1,1),A1(2,1),A1(3,1),'CH1','VerticalAlignment','bottom');
  hold on
  text(A2(1,1),A2(2,1),A2(3,1),'CH2','VerticalAlignment','bottom');
  hold on
  text(Final2{1,1}(1,1),Final2{1,1}(2,1),Final2{1,1}(3,1),'CH3','VerticalAlignment','bottom');
  hold on
  
ii=length(A1);
%%%%%%%%%%%%%��ͷ����%%%%%%%%%%%%%%%%%%
for i=2:ii
if find(A1(2,i)==A1(2,1:i-1))
    plot3([A1(1,1),A1(1,i)],[A1(2,1),A1(2,i)],[A1(3,1),A1(3,i)],'k','LineWidth',1.5)
else
    plot3([A1(1,1),A1(1,i)],[A1(2,1),A1(2,i)],[A1(3,1),A1(3,i)],'k','LineWidth',1.5)
end
end
ii=length(A2);
for i=2:ii
if find(A2(2,i)==A2(2,1:i-1))
    plot3([A2(1,1),A2(1,i)],[A2(2,1),A2(2,i)],[A2(3,1),A2(3,i)],'m','LineWidth',1.5)
else
    plot3([A2(1,1),A2(1,i)],[A2(2,1),A2(2,i)],[A2(3,1),A2(3,i)],'m','LineWidth',1.5)
end
end
ee=length(Final2);
for i=1:ee
    
    if i==1
       A3=Final2{1,i};
    disp(A3)
    d=size(A3,2);
    for j=2:d
        plot3([A3(1,1),A3(1,j)],[A3(2,1),A3(2,j)],[A3(3,1),A3(3,j)],'g','LineWidth',1.5)
        hold on
    end
    end
    
    if i>1
    A3=Final2{1,i};
    disp(A3)
    d=size(A3,2);
    for j=2:d
        plot3([A3(1,1),A3(1,j)],[A3(2,1),A3(2,j)],[A3(3,1),A3(3,j)],'c','LineWidth',1.5)
        hold on
    end
    end
end
c=plot3([Final3(1,1),Final3(1,2)],[Final3(2,1),Final3(2,2)],[Final3(3,1),Final3(3,2)],'LineWidth',1.5);
set(c,'color',[1, 0.6732, 0]);
hold on
figure_FontSize=8;
set(get(gca,'XLabel'),'FontSize',figure_FontSize,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',figure_FontSize,'Vertical','middle');
set(findobj('FontSize',10),'FontSize',figure_FontSize);
set(gcf,'Position',[100 100 260 220]);
xlabel('x/m');
 ylabel('y/m');
 zlabel('z/m')
 %view([0 90])
%title('EESOA-MAC�㷨')

%% ��ͼ�����������ص㣬�����ŵ�4���ȴ��㡣�ص�ΪFinal�������ÿ��������Ŀ�ͷ��һ��%%
%%%%%%%%%%%%%%%%�ŵ�����Final3,4���ȴ������Point�С�%%%%%%%%%%%%%
figure (2)
% CC=C;
% [~,bb]=find(A1(1,1)==CC);
% CC(:,[bb])=[];
% [~,bb]=find(A2(1,1)==CC);
% CC(:,[bb])=[];
% [~,bb]=find(Final2{1,1}(1,1)==CC);
% CC(:,[bb])=[];
% [~,bb]=find(Final2{1,2}(1,1)==CC);
% CC(:,[bb])=[];
% [~,bb]=find(Final2{1,3}(1,1)==CC);
% CC(:,[bb])=[]; ��ͼʱ��
% scatter3(CC(1,:),CC(2,:),CC(3,:),80,'filled','LineWidth',1.5);
% hold on
scatter3(C(1,:),C(2,:),C(3,:),80,'filled','LineWidth',1.5);
hold on
% scatter3(A1(1,1),A1(2,1),A1(3,1),80,'r','filled','LineWidth',1.5);
% hold on
% scatter3(A2(1,1),A2(2,1),A2(3,1),80,'r','filled','LineWidth',1.5);
% hold on
% scatter3(Final2{1,1}(1,1),Final2{1,1}(2,1),Final2{1,1}(3,1),80,'r','filled','LineWidth',1.5);
% hold on
% scatter3(Final2{1,2}(1,1),Final2{1,2}(2,1),Final2{1,2}(3,1),80,'k','filled','LineWidth',1.5);
% hold on
% scatter3(Final2{1,3}(1,1),Final2{1,3}(2,1),Final2{1,3}(3,1),80,'k','filled','LineWidth',1.5);
% hold on %%��ͼʱ�õ�
%text(C(1,Path(1,1)),C(2,Path(1,1)),'Ns','VerticalAlignment','bottom');
%text(A1(1,1),A1(2,1),'Ch','VerticalAlignment','bottom');
%text(A2(1,1),A2(2,1),'Ch','VerticalAlignment','bottom');%%��ͷ
e=length(Point);
 for i=1:e
 text(C(1,Point(1,i)),C(2,Point(1,i)),C(3,Point(1,i)),'Wp','VerticalAlignment','bottom');
 end  %%%%%�ȴ��ڵ�
  hold on
  
  text(A1(1,1),A1(2,1),A1(3,1),'CH1','VerticalAlignment','bottom');
  hold on
  text(A2(1,1),A2(2,1),A2(3,1),'CH2','VerticalAlignment','bottom');
  hold on
  text(Final2{1,1}(1,1),Final2{1,1}(2,1),Final2{1,1}(3,1),'CH3','VerticalAlignment','bottom');
  hold on
  
ii=length(A1);
%%%%%%%%%%%%%��ͷ����%%%%%%%%%%%%%%%%%%
for i=2:ii
if find(A1(2,i)==A1(2,1:i-1))
    plot3([A1(1,1),A1(1,i)],[A1(2,1),A1(2,i)],[A1(3,1),A1(3,i)],'k','LineWidth',1.5)
else
    plot3([A1(1,1),A1(1,i)],[A1(2,1),A1(2,i)],[A1(3,1),A1(3,i)],'k','LineWidth',1.5)
end
end
ii=length(A2);
for i=2:ii
if find(A2(2,i)==A2(2,1:i-1))
    plot3([A2(1,1),A2(1,i)],[A2(2,1),A2(2,i)],[A2(3,1),A2(3,i)],'m','LineWidth',1.5)
else
    plot3([A2(1,1),A2(1,i)],[A2(2,1),A2(2,i)],[A2(3,1),A2(3,i)],'m','LineWidth',1.5)
end
end
ee=length(Final2);
for i=1:ee
    
    if i==1
       A3=Final2{1,i};
    disp(A3)
    d=size(A3,2);
    for j=2:d
        plot3([A3(1,1),A3(1,j)],[A3(2,1),A3(2,j)],[A3(3,1),A3(3,j)],'g','LineWidth',1.5)
        hold on
    end
    end
    
    if i>1
    A3=Final2{1,i};
    disp(A3)
    d=size(A3,2);
    for j=2:d
        plot3([A3(1,1),A3(1,j)],[A3(2,1),A3(2,j)],[A3(3,1),A3(3,j)],'c','LineWidth',1.5)
        hold on
    end
    end
end
c=plot3([Final3(1,1),Final3(1,2)],[Final3(2,1),Final3(2,2)],[Final3(3,1),Final3(3,2)],'LineWidth',1.5);
set(c,'color',[1, 0.6732, 0]);
hold on
figure_FontSize=8;
set(get(gca,'XLabel'),'FontSize',figure_FontSize,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',figure_FontSize,'Vertical','middle');
set(findobj('FontSize',10),'FontSize',figure_FontSize);
set(gcf,'Position',[100 100 260 220]);
xlabel('x/m');
 ylabel('y/m');
 zlabel('z/m')
view([0 90])
%title('EESOA-MAC�㷨')
        
        




