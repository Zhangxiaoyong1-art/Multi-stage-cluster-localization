function DrawPicture(anchor, sensor, netss, netsa)
figure (7)
%UNTITLED3 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
sz = 60;  %���С
scatter3(anchor(1,:),anchor(2,:),anchor(3,:), sz,'b','d', 'LineWidth',1.5)
hold on; %anchorΪê�ڵ�
scatter3(sensor(1,:),sensor(2,:),sensor(3,:), sz,'r','o', 'LineWidth',1.5)
hold on; %
[row, ~] = size(netss);
n = uint8(row);
for i = 1:n
    for j = 1:n
        if netss(i,j)~=0
            x = [sensor(1,i),sensor(1,j)];
            y = [sensor(2,i),sensor(2,j)];
            z = [sensor(3,i),sensor(3,j)];
            plot3(x,y,z,'-','LineWidth',1,'color','g')
            hold on;
        end
    end
end
[row, col] = size(netsa);
n = uint8(row);
m = uint8(col);
for i = 1:n
    for j = 1:m
        if netsa(i,j)~=0
            x = [anchor(1,i),sensor(1,j)];
            y = [anchor(2,i),sensor(2,j)];
            z = [anchor(3,i),sensor(3,j)];
            plot3(x,y,z,'-','LineWidth',1,'color','g')
            hold on;
        end
    end
end
end

