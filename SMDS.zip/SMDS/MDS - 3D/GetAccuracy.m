function accuracy = GetAccuracy(distance1,distance2)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[n,~] = size(distance1);
all = sum(sum(distance1));
diff = distance1 - distance2;
diff = abs(diff);
num = 0;
for i=1:n
    for j=1:n
        if(distance1(i,j)==0) || i<=4 || j<=4
            diff(i,j) = 0;
        end
    end
end
accuracy = 1 - sum(sum(diff))/all;
end

