function SSE = GetSSE(distance1, distance2)
%UNTITLED7 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[n,~] = size(distance1);
diff = distance1 - distance2;
diff = diff.^2;
num = 0;
for i=1:n
    for j=1:n
        if(distance1(i,j)==0) || i<=4 || j<=4
            diff(i,j) = 0;
            num = num + 1;
        end
    end
end
SSE = sum(sum(diff))/(n*n);
end