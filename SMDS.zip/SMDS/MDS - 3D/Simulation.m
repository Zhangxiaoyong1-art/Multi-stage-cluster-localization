function [anchor, netss, netsa, sensor] = Simulation(anchorNum, sensorNum, prange, dem)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   anchorNum������ż��,dem��ά��
drange = 1500;   %����ķ�Χ
anchor = [415,1320,1051,785;624,789,64,454;146,321,106,220];
sensor = [400 1000 635 612 456 1036 121  784  719 236  124 1400 1000 1470 154 1500;
    400 842 974 145 982 454 698  256  351 1014 564 1210 1210 360 1190 1500;
    130 200 180 195 150 177 90  230  270 311 300 110 240 140 190 200];
netsa = zeros(anchorNum,sensorNum);
Derror=abs(randn(anchorNum,sensorNum)*0.001);%abs(0.001*rand(1))Ϊ������
save('Derror.mat','Derror')
% �����ֵ0
for i = 1:anchorNum
    for j = 1:sensorNum
        dist = 0;
        for k = 1:dem
            dist = dist + (anchor(k,i) - sensor(k,j))^2;
        end
        dist = sqrt(dist) +Derror(i,j);
        if dist <= drange
           netsa(i,j) = dist;
        end
    end
end
netss = CalculateDistance(sensor);
netss(netss>drange)=0;
end

