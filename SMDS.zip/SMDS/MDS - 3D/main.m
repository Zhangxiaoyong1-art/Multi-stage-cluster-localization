clear,close all;
[anchor, netss, netsa,sensor] = Simulation(4, 16, 200, 3);
save('anchor.mat','anchor');
save('sensor.mat','sensor');
save('netss.mat','netss');
save('netsa.mat','netsa');
DrawPicture(anchor,sensor,netss,netsa);
saveas(gcf,'map.jpg')